<p>&copy; <?php echo date("Y"); ?> Krenich Studios. All Rights Reserved. | <a href="<?php echo $base_path; ?>help/getting-started.php">Help</a> | <a href="<?php echo $base_path; ?>contact.php">Contact</a></p>
<script src="<?php echo $base_path; ?>js/main.js"></script>
